-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Tempo de geração: 08/05/2015 às 05:05
-- Versão do servidor: 5.6.15-log
-- Versão do PHP: 5.5.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `noponto`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `empresas`
--

CREATE TABLE IF NOT EXISTS `empresas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_original` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_original_UNIQUE` (`id_original`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `linhas`
--

CREATE TABLE IF NOT EXISTS `linhas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT '[NOME]',
  `empresa_id` int(11) NOT NULL,
  `rota_ida_id` int(11) NOT NULL,
  `rota_volta_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome_original_UNIQUE` (`nome`),
  UNIQUE KEY `empresa_id_UNIQUE` (`empresa_id`),
  KEY `fk_linhas_rotas1_idx` (`rota_ida_id`),
  KEY `fk_linhas_rotas2_idx` (`rota_volta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pontos`
--

CREATE TABLE IF NOT EXISTS `pontos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_original` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci DEFAULT 'Ponto',
  `gps` point NOT NULL,
  `sentido` int(11) NOT NULL DEFAULT '0' COMMENT 'Em graus.',
  `tipo` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gps_UNIQUE` (`gps`(25)),
  UNIQUE KEY `id_original_UNIQUE` (`id_original`),
  KEY `fk_pontos_ponto_tipos_idx` (`tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ponto_tipos`
--

CREATE TABLE IF NOT EXISTS `ponto_tipos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_original` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Tipos de ponto (ponto comum, terminal, etc.).',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `rotas`
--

CREATE TABLE IF NOT EXISTS `rotas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_original` int(11) NOT NULL,
  `numero` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `nome_original` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sentido` varchar(45) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Ida ou volta.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_original_UNIQUE` (`id_original`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=397 ;

--
-- Fazendo dump de dados para tabela `rotas`
--

INSERT INTO `rotas` (`id`, `id_original`, `numero`, `nome_original`, `sentido`) VALUES
(1, 17100, '715', 'Rio Novo Ponta Verde via Bebedouro', 'ida'),
(2, 17101, '715', 'Rio Novo Ponta Verde via Bebedouro', 'volta'),
(3, 17102, '58', 'Fernão Velho Centro / via Farol / Ferinha', 'ida'),
(4, 17103, '58', 'Centro Fernão Velho / via Farol / Ferinha', 'volta'),
(5, 17106, '57', 'Rio Novo Centro via Farol / Colina', 'volta'),
(6, 17107, '57', 'Rio Novo Centro via Farol / Colina', 'ida'),
(7, 17108, '69', 'Clima Bom Centro via Farol', 'ida'),
(8, 17109, '69', 'Clima Bom Centro via Farol', 'volta'),
(9, 17110, '711', 'UFAL Ponta Verde via Bebedouro / Jacintinho', 'volta'),
(10, 17111, '711', 'UFAL Ponta Verde via Bebedouro / Jacintinho', 'ida'),
(11, 17112, '72', 'Gama Lins Ponta Verde via Colina / Morada / Farol', 'ida'),
(12, 17113, '72', 'Gama Lins Ponta Verde via Colina / Morada / Farol', 'volta'),
(13, 17114, '7151', 'Rosane Collor Ponta Verde via Bebedouro', 'volta'),
(14, 17115, '7151', 'Rosane Collor Ponta Verde via Bebedouro', 'ida'),
(15, 17116, '59', 'Rio Novo Centro / via Bebedouro', 'ida'),
(16, 17117, '59', 'Rio Novo Centro / via Bebedouro', 'volta'),
(17, 17118, '64', 'Rosane Collor Centro / via Bebedouro', 'volta'),
(18, 17119, '64', 'Rosane Collor Centro / via Bebedouro', 'ida'),
(19, 17120, '710', 'Chã da Jaqueira / Ponta Verde - via Boa Vista', 'ida'),
(20, 17121, '710', 'Chã da Jaqueira / Ponta Verde - via Boa Vista', 'volta'),
(21, 17122, '709', 'Chã da Jaqueira / Ponta Verde - Mutirão', 'volta'),
(22, 17123, '709', 'Chã da Jaqueira / Ponta Verde - Mutirão', 'ida'),
(23, 17124, '51', 'Santos Dumond Centro via Farol / Bomba do Gonzaga', 'ida'),
(24, 17125, '51', 'Santos Dumond Centro via Farol / Bomba do Gonzaga', 'volta'),
(25, 17126, '70', 'Osman Loureiro Centro via Farol', 'volta'),
(26, 17127, '70', 'Osman Loureiro Centro via Farol', 'ida'),
(27, 17128, '65', 'Rosane Collor Centro via Farol', 'ida'),
(28, 17129, '65', 'Rosane Collor Centro via Farol', 'volta'),
(29, 17130, '716', 'Clima Bom Ponta Verde via Farol', 'volta'),
(30, 17131, '716', 'Clima Bom Ponta Verde via Farol', 'ida'),
(31, 17132, '7091', 'Chã Nova Ponta Verde', 'ida'),
(32, 17133, '7091', 'Chã Nova Ponta Verde via Farol', 'volta'),
(33, 17134, '60', 'Chã da Jaqueira / Centro - via Bebedouro', 'ida'),
(34, 17135, '60', 'Chã da Jaqueira / Centro - via Bebedouro', 'volta'),
(35, 17136, '71', 'Osman Loureiro Centro via Bebedouro', 'volta'),
(36, 17137, '71', 'Osman Loureiro Centro via Bebedouro', 'ida'),
(37, 17138, '108', 'Clima Bom Trapiche via Jaqueira / Colina', 'ida'),
(38, 17139, '108', 'Clima Bom Trapiche via Ferinha / Colina', 'volta'),
(39, 17140, '108', 'Clima Bom Trapiche via Jaqueira / Colina', 'volta'),
(40, 17141, '108', 'Clima Bom Trapiche via Feirinha / Colina', 'ida'),
(41, 17162, '602', 'Salvador Lyra / Iguatemi', 'volta'),
(42, 17163, '602', 'Salvador Lyra / Iguatemi', 'ida'),
(43, 17168, '33', 'José Tenório / Centro - Via Rotary', 'ida'),
(44, 17169, '33', 'José Tenório / Centro - Via Rotary', 'volta'),
(45, 17170, '33', 'José Tenório / Centro - Via Gruta', 'ida'),
(46, 17171, '33', 'José Tenório / Centro - Via Gruta', 'volta'),
(47, 17172, '37', 'Salvador Lyra / Centro - Farol', 'ida'),
(48, 17173, '37', 'Salvador Lyra / Centro - Farol', 'volta'),
(49, 17174, '39', 'Cleto Marques / Centro', 'ida'),
(50, 17175, '39', 'Cleto Marques / Centro', 'volta'),
(51, 17176, '36', 'Dubeau x Leão / Centro', 'ida'),
(52, 17177, '36', 'Dubeau x Leão / Centro', 'volta'),
(53, 17180, '17', 'São Jorge / Ponta Verde', 'volta'),
(54, 17181, '17', 'São Jorge / Ponta Verde', 'ida'),
(55, 17182, '27', 'Vila SAEM / Centro', 'ida'),
(56, 17183, '27', 'Vila SAEM / Centro', 'volta'),
(57, 17188, '608', 'Gruta / Iguatemi', 'volta'),
(58, 17189, '608', 'Gruta / Iguatemi', 'ida'),
(59, 17190, '35', 'Ouro Preto / Centro', 'volta'),
(60, 17191, '35', 'Ouro Preto / Centro', 'ida'),
(61, 17192, '60', 'São Jorge / Trapiche', 'volta'),
(62, 17193, '60', 'São Jorge / Trapiche', 'ida'),
(63, 17198, '32', 'Novo Mundo / Centro', 'ida'),
(64, 17199, '32', 'Novo Mundo / Centro', 'volta'),
(65, 17200, '30', 'Gruta / Centro', 'volta'),
(66, 17201, '30', 'Gruta / Centro', 'ida'),
(67, 17202, '12', 'Jose S. Pei x oto / Centro', 'ida'),
(68, 17203, '12', 'Jose S. Pei x oto / Centro', 'volta'),
(69, 17204, '13', 'Cruz das Almas / Centro', 'volta'),
(70, 17205, '13', 'Cruz das Almas / Centro', 'ida'),
(71, 17206, '830', 'Integração Grota do Arroz', 'ida'),
(72, 17207, '830', 'Integração Grota do Arroz', 'volta'),
(73, 17208, '213', 'Vergel / Ponta Verde - Via Avenida', 'volta'),
(74, 17209, '213', 'Vergel / Ponta Verde - Via Avenida', 'ida'),
(75, 17210, '70', 'Sanatório / Ponta Verde', 'volta'),
(76, 17211, '70', 'Sanatório / Ponta Verde', 'ida'),
(77, 17212, '840', 'Integração Saúde / Pescaria', 'volta'),
(78, 17213, '840', 'Integração Saúde / Pescaria', 'ida'),
(79, 17218, '599', 'Cruz das Almas / Corujão', 'volta'),
(80, 17219, '599', 'Cruz das Almas / Corujão', 'ida'),
(81, 17220, '199', 'Vaticano / Corujão', 'volta'),
(82, 17221, '199', 'Vaticano / Corujão', 'ida'),
(83, 17222, '603', 'Mirante / Vergel', 'ida'),
(84, 17223, '603', 'Mirante / Vergel', 'volta'),
(85, 17224, '208', 'Jacarecica / Vergel', 'ida'),
(86, 17225, '208', 'Jacarecica / Vergel', 'volta'),
(87, 17226, '210', 'Ponta Verde / Vergel', 'ida'),
(88, 17227, '210', 'Ponta Verde / Vergel', 'volta'),
(89, 17230, '197', 'Ipioca / Trapiche - Corujão', 'ida'),
(90, 17231, '197', 'Ipioca / Trapiche - Corujão', 'volta'),
(91, 17232, '221', 'Saúde / Mercado - Via Poço', 'volta'),
(92, 17233, '221', 'Saúde / Mercado - Via Poço', 'ida'),
(93, 17234, '25', 'Sanatório / Centro', 'volta'),
(94, 17235, '25', 'Sanatório / Centro', 'ida'),
(95, 17246, '022A', 'São Jorge / Centro - Via Farol', 'ida'),
(96, 17247, '022A', 'São Jorge / Centro - Via Farol', 'volta'),
(97, 17248, '022B', 'São Jorge / Centro - Via Jacintinho', 'volta'),
(98, 17249, '022B', 'São Jorge / Centro - Via Jacintinho', 'ida'),
(99, 17252, '042G', 'Benedito Bentes / Centro - Via S. Lúcia / Conjuntos', 'ida'),
(100, 17258, '604', 'UFAL / Ipioca - Via Ladeira do Óleo', 'ida'),
(101, 17272, '024A', 'Sanatório / Sinimbu', 'ida'),
(102, 17287, '042G', 'Benedito Bentes / Centro - Via S. Lúcia / Conjuntos', 'volta'),
(103, 17288, '024A', 'Sanatório / Sinimbu', 'volta'),
(104, 17299, '042G', 'Benedito Bentes / Centro - Via S. Lúcia - Gua x uma', 'ida'),
(105, 17300, '042G', 'Benedito Bentes / Centro - Via S. Lúcia - Gua x uma', 'volta'),
(106, 17301, '604', 'UFAL / Ipioca - Via Ladeira do Óleo', 'volta'),
(107, 17318, '798', 'Corujão', 'ida'),
(108, 17319, '798', 'Corujão', 'volta'),
(109, 17320, '802', 'Colina Benedito Bentes via Correios', 'volta'),
(110, 17321, '802', 'Colina Benedito Bentes via Clima Bom', 'ida'),
(111, 17322, '68', 'Colina Poço via Sanatório', 'ida'),
(112, 17323, '68', 'Colina Poço via Sanatório', 'volta'),
(113, 17324, '2', 'Chã Nova / Integração (Via Morada)', 'volta'),
(114, 17325, '2', 'Chã Nova / Integração (Via Morada)', 'ida'),
(115, 17400, '604', 'UFAL / Ipioca - Via Lad. Óleo / Eustáquio Gomes', 'volta'),
(116, 17401, '604', 'UFAL / Ipioca - Via Lad. Óleo / Eustáquio Gomes', 'ida'),
(117, 17415, '042M', 'B. Bentes / Centro (Santa. Lúcia)', 'ida'),
(118, 17421, '042M', 'B. Bentes / Centro (Santa Lúcia / Conjuntos)', 'ida'),
(119, 17423, '042M', 'B. Bentes / Centro (Distrito)', 'ida'),
(120, 17424, '042M', 'B. Bentes / Centro (Distrito / Conjuntos)', 'ida'),
(121, 17425, '042M', 'B. Bentes / Centro (Santa. Lúcia)', 'volta'),
(122, 17426, '042M', 'B. Bentes / Centro (Santa Lúcia / Conjuntos)', 'volta'),
(123, 17427, '042M', 'B. Bentes / Centro (Distrito)', 'volta'),
(124, 17428, '042M', 'B. Bentes / Centro (Distrito / Conjuntos)', 'volta'),
(125, 17597, '042G', 'Benedito Bentes / Centro - Via Distrito - Gua x uma', 'volta'),
(126, 17599, '042G', 'Benedito Bentes / Centro - Via Distrito - Gua x uma', 'ida'),
(127, 17600, '042G', 'Benedito Bentes / Centro - Via Distrito / Conjuntos', 'ida'),
(128, 17601, '042G', 'Benedito Bentes / Centro - Via Distrito / Conjuntos', 'volta'),
(129, 17752, '66', 'Santo Amaro / Centro', 'volta'),
(130, 17753, '66', 'Santo Amaro / Centro', 'ida'),
(131, 17754, '13', 'Cruz das Almas / Centro - Via Josefa de Melo', 'ida'),
(132, 17757, '223B', 'Ipioca / Ponta Verde', 'volta'),
(133, 17758, '223B', 'Ipioca / Ponta Verde', 'ida'),
(134, 17769, '13', 'Cruz das Almas / Centro - Via Josefa de Melo', 'volta'),
(135, 17870, '223A', 'Ipioca / Poço - Via Mercado', 'ida'),
(136, 17873, '223A', 'Ipioca / Poço - Via Mercado', 'volta'),
(137, 18666, '806', 'Benedito Bentes Colina Via Clima Bom', 'volta'),
(138, 18667, '806', 'Benedito Bentes Colina Via Correios', 'ida'),
(139, 19837, '802', 'Colina Benedito Bentes via Correios', 'ida'),
(140, 19838, '802', 'Colina Benedito Bentes via Clima Bom', 'volta'),
(141, 19887, '024A', 'Sanatório / Sinimbu - Via Murilópolis', 'volta'),
(142, 19888, '024A', 'Sanatório / Sinimbu - Via Murilópolis', 'ida'),
(143, 19903, '806', 'Benedito Bentes Colina Via Clima Bom', 'ida'),
(144, 19904, '806', 'Benedito Bentes Colina Via Correios', 'volta'),
(145, 20379, '711', 'UFAL via Colina / Cambona / Jaraguá / Ponta Verde - via Colina II', 'volta'),
(146, 20380, '711', 'UFAL via Colina / Cambona / Jaraguá / Ponta Verde - via Colina II', 'ida'),
(147, 20381, '108', 'Colina II', 'ida'),
(148, 20382, '108', 'Colina II', 'volta'),
(149, 20441, '22', 'São Jorge / Centro - Via Farol', 'ida'),
(150, 20442, '22', 'São Jorge / Centro - Via Farol', 'volta'),
(151, 20443, '22', 'São Jorge / Centro - Via Jacintinho', 'ida'),
(152, 20444, '22', 'São Jorge / Centro - Via Jacintinho', 'volta'),
(153, 20445, '022A', 'São Jorge / Centro - Via Farol / Volta Jacintinho', 'ida'),
(154, 21100, '604', 'UFAL / Ipioca - Via Josefa de Melo', 'volta'),
(155, 21101, '604', 'UFAL / Ipioca - Via Josefa de Melo', 'ida'),
(156, 21102, '604', 'UFAL / Ipioca - Josefa de Melo - Eustáquio', 'ida'),
(157, 21108, '604', 'UFAL / Ipioca - Josefa de Melo - Eustáquio', 'volta'),
(158, 21259, '609', 'SAEM / Iguatemi', 'ida'),
(159, 21260, '609', 'SAEM / Iguatemi', 'volta'),
(160, 22028, '022A', 'São Jorge / Centro - Via Farol / Volta Jacintinho', 'volta'),
(161, 22029, '022B', 'São Jorge / Centro - Via Jacintinho / Volta Farol', 'ida'),
(162, 22030, '022B', 'São Jorge / Centro - Via Jacintinho / Volta Farol', 'volta'),
(163, 22493, '56', 'João Sampaio / Centro', 'volta'),
(164, 22494, '56', 'João Sampaio / Centro', 'ida'),
(165, 22495, '107', 'Cruz das Almas / Trapiche', 'volta'),
(166, 22496, '107', 'Cruz das Almas / Trapiche', 'ida'),
(167, 22497, '201', 'Circular I - (Pontal)', 'ida'),
(168, 22498, '201', 'Circular I - (Pontal)', 'volta'),
(169, 22499, '201', 'Circular I - (Trapiche)', 'volta'),
(170, 22500, '201', 'Circular I - (Trapiche)', 'ida'),
(171, 22501, '202', 'Circular II (Trapiche)', 'volta'),
(172, 22502, '202', 'Circular II (Trapiche)', 'ida'),
(173, 22503, '407', 'Trapiche / Hospital Usineiros', 'volta'),
(174, 22504, '407', 'Trapiche / Hospital Usineiros', 'ida'),
(175, 22505, '503', 'Joaquim Leão / Feitosa', 'volta'),
(176, 22506, '503', 'Joaquim Leão / Feitosa', 'ida'),
(177, 22507, '605', 'Pontal / Iguatemi', 'ida'),
(178, 22508, '605', 'Pontal / Iguatemi', 'volta'),
(179, 22509, '611', 'Vergel / Jatiúca', 'volta'),
(180, 22510, '611', 'Vergel / Jatiúca', 'ida'),
(181, 22511, '713', 'Joaquim Leão / Ponta Verde', 'ida'),
(182, 22512, '713', 'Joaquim Leão / Ponta Verde', 'volta'),
(183, 22513, '797', 'Joaquim Leão / Ponta Verde - Corujão', 'ida'),
(184, 22514, '797', 'Joaquim Leão / Ponta Verde - Corujão', 'volta'),
(185, 22515, '906', 'Pontal / UFAL', 'ida'),
(186, 22516, '906', 'Pontal / UFAL', 'volta'),
(187, 22517, '906', 'Trapiche / UFAL', 'volta'),
(188, 22518, '906', 'Trapiche / UFAL', 'ida'),
(189, 22519, '103', 'Mirante / Trapiche', 'volta'),
(190, 22520, '103', 'Mirante / Trapiche', 'ida'),
(191, 22521, '50', 'Pontal / Rodoviária', 'ida'),
(192, 22522, '50', 'Pontal / Rodoviária', 'volta'),
(193, 22523, '46', 'Village Campestre II x Centro / Farol', 'volta'),
(194, 22524, '46', 'Village Campestre II x Centro / Farol', 'ida'),
(195, 22525, '53', 'Graciliano Ramos x Centro', 'ida'),
(196, 22526, '53', 'Graciliano Ramos x Centro', 'volta'),
(197, 22527, '53', 'Graciliano Ramos x Centro - Acauã', 'ida'),
(198, 22528, '53', 'Graciliano Ramos x Centro - Acauã', 'volta'),
(199, 22529, '805', 'Gua x uma x Integrado B. Bentes', 'ida'),
(200, 22530, '805', 'Gua x uma x Integrado B. Bentes', 'volta'),
(201, 22531, '214', 'Henrique Equelman x Vergel', 'ida'),
(202, 22532, '214', 'Henrique Equelman x Vergel', 'volta'),
(203, 22533, '97', 'Village Campestre II x Centro / Corujão', 'ida'),
(204, 22534, '97', 'Village Campestre II x Centro / Corujão', 'volta'),
(205, 22535, '110', 'Graciliano Ramos x Trapiche / Feitosa', 'volta'),
(206, 22536, '110', 'Graciliano Ramos x Trapiche / Feitosa', 'ida'),
(207, 22537, '1101', 'Village II x Trapiche / Cambuci', 'ida'),
(208, 22538, '1101', 'Village II x Trapiche / Cambuci', 'volta'),
(209, 22539, '707', 'Graciliano Ramos x Ponta Verde', 'ida'),
(210, 22540, '707', 'Graciliano Ramos x Ponta Verde', 'volta'),
(211, 22541, '7071', 'Village II x P. Verde / Cambuci', 'ida'),
(212, 22542, '7071', 'Village II x P. Verde / Cambuci', 'volta'),
(213, 22543, '204', 'José da Silva Pei x oto x J. Leão / Iguatemi', 'volta'),
(214, 22544, '204', 'José da Silva Pei x oto x J. Leão', 'volta'),
(215, 22545, '204', 'José da Silva Pei x oto x J. Leão / Iguatemi', 'ida'),
(216, 22546, '204', 'José da Silva Pei x oto x J. Leão', 'ida'),
(217, 22547, '708', 'Cruz das Almas x Ponta Verde', 'volta'),
(218, 22548, '708', 'Cruz das Almas x P. Verde / Josefa de Melo', 'ida'),
(219, 22549, '708', 'Cruz das Almas x Ponta Verde', 'ida'),
(220, 22550, '708', 'Cruz das Almas x P. Verde / Josefa de Melo', 'volta'),
(221, 22551, '808', 'Cachoeira do Meirim x Integrado B. Bentes', 'ida'),
(222, 22552, '808', 'Cachoeira do Meirim x Integrado B. Bentes', 'volta'),
(223, 22553, '2141', 'Henrique Equelman x Vergel / Alto da Alegria', 'ida'),
(224, 22554, '2141', 'Henrique Equelman x Vergel / Alto da Alegria', 'volta'),
(225, 22555, '48', 'B. Bentes x Centro / Jacintinho (Frei Damião)', 'volta'),
(226, 22556, '48', 'B. Bentes x Centro / Jacintinho (Frei Damião)', 'ida'),
(227, 22557, '52', 'Forene x Centro / Cambuci / T. Rodoviário / Jardins', 'ida'),
(228, 22558, '52', 'Forene x Centro / Cambuci / T. Rodoviário / Jardins', 'volta'),
(229, 22559, '607', 'Eustáquio Gomes x Iguatemi / Jardins', 'volta'),
(230, 22560, '607', 'Eustáquio Gomes x Iguatemi / Jardins', 'ida'),
(231, 22561, '048B', 'B. Bentes x Centro / Josefa de Melo (Mocambo)', 'volta'),
(232, 22562, '048B', 'B. Bentes x Centro / Jacintinho / Recantos (Mocambo)', 'ida'),
(233, 22563, '048B', 'B. Bentes x Centro / Jacintinho / Recantos (Mocambo)', 'volta'),
(234, 22564, '048B', 'B. Bentes x Centro / Josefa de Melo (Mocambo)', 'ida'),
(235, 22565, '048D', 'B. Bentes x Centro / Jacintinho (Moacir Andrade)', 'volta'),
(236, 22566, '048D', 'B. Bentes x Centro / Jacintinho (Moacir Andrade)', 'ida'),
(237, 22567, '49', 'Eustáquio Gomes x Centro / Farol', 'volta'),
(238, 22568, '49', 'Eustáquio Gomes x Centro / Farol / Jardins', 'ida'),
(239, 22569, '196', 'Corujão x Trapiche / E. Gomes', 'volta'),
(240, 22570, '196', 'Corujão x Trapiche / E. Gomes', 'ida'),
(241, 22571, '230', 'Forene x Trapiche / Farol / Poço / Jardins', 'ida'),
(242, 22572, '230', 'Forene x Trapiche / Farol / Poço / Jardins', 'volta'),
(243, 22573, '706', 'Eustáquio Gomes x P. Verde / S. Lyra / Jardins', 'ida'),
(244, 22574, '706', 'Eustáquio Gomes x P. Verde / S. Lyra / Jardins', 'volta'),
(245, 22575, '706', 'Eustáquio Gomes x P. Verde / Corinthians / Jardins', 'volta'),
(246, 22576, '706', 'Eustáquio Gomes x P. Verde / Corinthians / Jardins', 'ida'),
(247, 22577, '712', 'Santos Dumont x Ponta Verde / Farol', 'volta'),
(248, 22578, '712', 'Santos Dumont x Ponta Verde / Farol', 'ida'),
(249, 22579, '2301', 'Santos Dumont x Trapiche / Farol / Poço', 'ida'),
(250, 22580, '2301', 'Santos Dumont x Trapiche / Farol / Poço', 'volta'),
(251, 22581, '704', 'B. Bentes x P. Verde / Farol (T. Integrado)', 'volta'),
(252, 22582, '704', 'B. Bentes x P. Verde / Farol (T. Integrado)', 'ida'),
(253, 22583, '903', 'Benedito Bentes x UFAL / Forene / E. Gomes / G. Ramos', 'volta'),
(254, 22584, '903', 'Benedito Bentes x UFAL / Forene / E. Gomes / G. Ramos', 'ida'),
(255, 22585, '803', 'João Sampaio x Terminal Integrado B. Bentes', 'volta'),
(256, 22586, '803', 'João Sampaio x Terminal Integrado B. Bentes', 'ida'),
(257, 22587, '804', 'Cidade Sorriso I x Terminal Integrado B. Bentes', 'volta'),
(258, 22588, '804', 'Cidade Sorriso I x Terminal Integrado B. Bentes', 'ida'),
(259, 22589, '809', 'Selma Bandeira x Terminal Integrado B. Bentes', 'ida'),
(260, 22590, '809', 'Selma Bandeira x Terminal Integrado B. Bentes', 'volta'),
(261, 22591, '812', 'CJ. Carminha x Terminal Integrado B. Bentes', 'volta'),
(262, 22592, '812', 'CJ. Carminha x Terminal Integrado B. Bentes', 'ida'),
(263, 22593, '703', 'B. Bentes x P. Verde / Gruta / H. Equelman (T. Integrado)', 'volta'),
(264, 22594, '703', 'B. Bentes x P. Verde / Gruta / H. Equelman (T. Integrado)', 'ida'),
(265, 22595, '104', 'B. Bentes x Trapiche (T. Integrado)', 'volta'),
(266, 22596, '104', 'B. Bentes x Trapiche (T. Integrado)', 'ida'),
(267, 22597, '217', 'B Bentes x Mercado / Feitosa (M Andrade)', 'ida'),
(268, 22598, '217', 'B Bentes x Mercado / Feitosa (M Andrade)', 'volta'),
(269, 22601, '216', 'Piabas x Mercado', 'ida'),
(270, 22602, '216', 'Piabas x Mercado', 'volta'),
(271, 22603, '704C', 'B. Bentes x P. Verde / Farol (Frei Damião)', 'volta'),
(272, 22604, '704C', 'B. Bentes x P. Verde / Farol (Frei Damião)', 'ida'),
(273, 22605, '704B', 'B. Bentes x P. Verde / Farol (Mocambo)', 'volta'),
(274, 22606, '704B', 'B. Bentes x P. Verde / Farol (Mocambo)', 'ida'),
(275, 22607, '704D', 'B. Bentes x P. Verde / Farol (Moacir Andrade)', 'ida'),
(276, 22608, '704D', 'B. Bentes x P. Verde / Farol (Moacir Andrade)', 'volta'),
(277, 22609, '704A', 'B. Bentes x P. Verde / Farol (Selma Bandeira)', 'ida'),
(278, 22610, '704A', 'B. Bentes x P. Verde / Farol (Selma Bandeira)', 'volta'),
(279, 22613, '41', 'Feitosa x Centro / Farol', 'volta'),
(280, 22614, '41', 'Feitosa x Centro / Farol', 'ida'),
(281, 22615, '703A', 'B. Bentes x P. Verde / Gruta (Selma Bandeira)', 'ida'),
(282, 22616, '703A', 'B. Bentes x P. Verde / Gruta (Selma Bandeira)', 'volta'),
(283, 22617, '703B', 'B. Bentes x P. Verde / Gruta (Mocambo)', 'volta'),
(284, 22618, '703B', 'B. Bentes x P. Verde / Gruta (Mocambo)', 'ida'),
(285, 22619, '703C', 'B. Bentes x P. Verde / Gruta (Frei Damião)', 'volta'),
(286, 22620, '703C', 'B. Bentes x P. Verde / Gruta (Frei Damião)', 'ida'),
(287, 22621, '104B', 'BENEDITO BENTES x TRAPICHE (Mocambo)', 'volta'),
(288, 22622, '104B', 'BENEDITO BENTES x TRAPICHE (Mocambo)', 'ida'),
(289, 22623, '807', 'José Aprígio x Terminal Integrado B. Bentes', 'volta'),
(290, 22624, '807', 'José Aprígio x Terminal Integrado B. Bentes', 'ida'),
(291, 22625, '703E', 'B. Bentes x P. Verde / Gruta (Gua x uma)', 'ida'),
(292, 22626, '703E', 'B. Bentes x P. Verde / Gruta (Gua x uma)', 'volta'),
(293, 25728, '214', 'Henrique Equelman x Vergel (Alto da Alegria)', 'ida'),
(294, 29329, '214', 'Henrique Equelman x Vergel (Alto da Alegria)', 'volta'),
(295, 29343, '7091', 'Chã nova / Ponta Verde', 'ida'),
(296, 29344, '7091', 'Chã nova / Ponta Verde', 'volta'),
(297, 29345, '7091', 'João Sampaio', 'volta'),
(298, 29346, '7091', 'João Sampaio', 'ida'),
(299, 29408, '97', 'Village Campestre II x Centro / Corujão', 'ida'),
(300, 29409, '97', 'Centro x Village Campestre II - Corujão', 'ida'),
(301, 29410, '196', 'Corujão x Trapiche / E. Gomes', 'ida'),
(302, 29412, '196', 'Corujão x Trapiche / E. Gomes', 'ida'),
(303, 29420, '97', 'Centro x Village Campestre II - Corujão', 'volta'),
(304, 29421, '97', 'Centro x Village Campestre II - Corujão', 'volta'),
(305, 29429, '796', 'Centro x Benedito Bentes (P. Verde) - Corujão', 'ida'),
(306, 29430, '796', 'Centro x Benedito Bentes (P. Verde) - Corujão', 'volta'),
(307, 29431, '796', 'Centro x Benedito Bentes - Corujão', 'volta'),
(308, 29432, '796', 'Centro x Benedito Bentes - Corujão', 'ida'),
(309, 29433, '196', 'Corujão x Trapiche / E. Gomes', 'volta'),
(310, 29434, '196', 'Corujão x Trapiche / E. Gomes', 'volta'),
(311, 29443, '606', 'José Tenório / Iguatemi - Serraria 3', 'volta'),
(312, 29444, '606', 'José Tenório / Iguatemi - Serraria 3', 'ida'),
(313, 30000, '104', 'B. Bentes x Trapiche (Mocambo)', 'ida'),
(314, 30503, '48', 'B. Bentes x Centro / Jacintinho (M. Andrade)', 'ida'),
(315, 30504, '48', 'B. Bentes x Centro / Jacintinho (M. Andrade)', 'volta'),
(316, 30505, '704', 'B. Bentes x P. Verde / Farol (Gua x uma)', 'volta'),
(317, 30506, '704', 'B. Bentes x P. Verde / Farol (Gua x uma)', 'ida'),
(318, 30507, '704', 'B. Bentes x P. Verde / Farol (Frei Damião)', 'volta'),
(319, 30508, '704', 'B. Bentes x P. Verde / Farol (Frei Damião)', 'ida'),
(320, 30509, '704C', 'B. Bentes x P. Verde / Farol (M. Andrade)', 'ida'),
(321, 30510, '704C', 'B. Bentes x P. Verde / Farol (Mocambo)', 'volta'),
(322, 30511, '704C', 'B. Bentes x P. Verde / Farol (Mocambo)', 'ida'),
(323, 30512, '704C', 'B. Bentes x P. Verde / Farol (Integrado)', 'ida'),
(324, 30513, '704C', 'B. Bentes x P. Verde / Farol (Integrado)', 'volta'),
(325, 30514, '704C', 'B. Bentes x P. Verde / Farol (M. Andrade)', 'volta'),
(326, 30515, '104', 'B. Bentes x Trapiche (Mocambo)', 'volta'),
(327, 30577, '703A', 'B. Bentes x P. Verde / Gruta (Integrado)', 'ida'),
(328, 30578, '703A', 'B. Bentes x P. Verde / Gruta (Integrado)', 'volta'),
(329, 30581, '704A', 'B. Bentes x P. Verde / Farol (Integrado)', 'ida'),
(330, 30582, '704A', 'B. Bentes x P. Verde / Farol (Integrado)', 'volta'),
(331, 30635, '704B', 'B. Bentes x P. Verde / Farol (Integrado)', 'ida'),
(332, 30636, '704B', 'B. Bentes x P. Verde / Farol (Integrado)', 'volta'),
(333, 31396, '223A', 'Ipioca / Poço / Via Saúde', 'ida'),
(334, 31397, '223A', 'Ipioca / Poço / Via Saúde', 'volta'),
(335, 31815, '223A', 'Ipioca / Poço - Via Pescaria', 'volta'),
(336, 31816, '223A', 'Ipioca / Poço - Via Pescaria', 'ida'),
(337, 31817, '703', 'B. Bentes x P. Verde / Gruta (T. Integrado)', 'ida'),
(338, 31818, '703', 'B. Bentes x P. Verde / Gruta (T. Integrado)', 'volta'),
(339, 31819, '703', 'B. Bentes x P. Verde / Gruta (Gua x uma)', 'volta'),
(340, 31820, '703', 'B. Bentes x P. Verde / Gruta (Gua x uma)', 'ida'),
(341, 31916, '608', 'Gruta / Iguatemi - Via Novo Mundo', 'ida'),
(342, 31934, '704A', 'B. Bentes x P. Verde / Farol (Frei Damião)', 'ida'),
(343, 31935, '704A', 'B. Bentes x P. Verde / Farol (Frei Damião)', 'volta'),
(344, 31960, '223B', 'Ipioca / Ponta Verde - Via Saúde', 'ida'),
(345, 31961, '223B', 'Ipioca / Ponta Verde - Via Saúde', 'volta'),
(346, 32704, '906', 'Pontal UFAL (Fim de Semana)', 'ida'),
(347, 32705, '906', 'Pontal UFAL (Fim de Semana)', 'volta'),
(348, 32863, '217', 'B Bentes x Mercado / Feitosa (C. Sorriso I)', 'ida'),
(349, 32936, '217', 'B Bentes x Mercado / Feitosa (C. Sorriso I)', 'volta'),
(350, 33214, '202', 'Circular II (Pontal)', 'ida'),
(351, 33215, '202', 'Circular II (Pontal)', 'volta'),
(352, 33549, '704', 'B. Bentes x P. Verde / Farol (Integrado / P.F.)', 'ida'),
(353, 33552, '704', 'B. Bentes x P. Verde / Farol (Integrado / P.F.)', 'volta'),
(354, 33799, '197', 'Ipioca / Trapiche - Corujão Via Saúde', 'volta'),
(355, 33800, '197', 'Ipioca / Trapiche - Corujão Via Saúde', 'ida'),
(356, 33859, '608', 'Gruta / Iguatemi - Via Novo Mundo', 'volta'),
(357, 33937, '805', 'Integração Jardim Royal', 'ida'),
(358, 33938, '805', 'Integração Novo Jardim', 'ida'),
(359, 33939, '7071', 'Village II x P. Verde / Shopping Pátio', 'ida'),
(360, 33946, '7071', 'Village II x P. Verde / Shopping Pátio', 'volta'),
(361, 33947, '49', 'Eustáquio Gomes x Centro / Farol', 'ida'),
(362, 33948, '52', 'Forene x Centro / Cambuci / Term. Rodoviário', 'ida'),
(363, 33949, '230', 'Forene x Trapiche / Farol / Poço', 'ida'),
(364, 33952, '607', 'Eustáquio Gomes x Iguatemi', 'ida'),
(365, 33953, '706', 'Eustáquio Gomes x P. Verde / S. Lyra', 'ida'),
(366, 33973, '230', 'Forene x Trapiche / Farol / Poço / UFAL', 'ida'),
(367, 33974, '230', 'Forene x Trapiche / Farol / Poço / UFAL', 'volta'),
(368, 34037, '105', 'Jardim Petrópolis x Trapiche / Farol', 'ida'),
(369, 34038, '105', 'Jardim Petrópolis x Trapiche / Farol', 'volta'),
(370, 34103, '796', 'Corujão Benedito Bentes x Ponta Verde', 'volta'),
(371, 34104, '796', 'Corujão Benedito Bentes x Ponta Verde', 'ida'),
(372, 34106, '798', 'FJ', 'volta'),
(373, 34133, '52', 'Forene x Centro / Cambuci / Term. Rodoviário', 'volta'),
(374, 34134, '607', 'Eustáquio Gomes x Iguatemi', 'volta'),
(375, 34135, '49', 'Eustáquio Gomes x Centro / Farol', 'volta'),
(376, 34136, '230', 'Forene x Trapiche / Farol / Poço', 'volta'),
(377, 34137, '706', 'Eustáquio Gomes x P. Verde / Corinthians', 'ida'),
(378, 34138, '706', 'Eustáquio Gomes x P. Verde / Corinthians', 'volta'),
(379, 34139, '706', 'Eustáquio Gomes x P. Verde / S. Lyra', 'volta'),
(380, 34935, '213', 'Vergel / Ponta Verde - Via Avenida / Saúde', 'volta'),
(381, 34986, '703C', 'B. Bentes x P. Verde / Gruta (Frei Damião / Direto)', 'ida'),
(382, 34987, '703C', 'B. Bentes x P. Verde / Gruta (Frei Damião / Direto)', 'volta'),
(383, 34998, '105', 'Jardim Petrópolis x Trapiche / Farol (Integração)', 'ida'),
(384, 34999, '104', 'B. Bentes x Trapiche (H. Equelman)', 'ida'),
(385, 35000, '704D', 'B. Bentes x P. Verde / Farol (Mocambo)', 'ida'),
(386, 35005, '704D', 'B. Bentes x P. Verde / Farol (Mocambo)', 'volta'),
(387, 35006, '906', 'Pontal / UFAL', 'volta'),
(388, 35007, '906', 'Pontal / UFAL', 'ida'),
(389, 35010, '104', 'B. Bentes x Trapiche (H. Equelman)', 'volta'),
(390, 35013, '105', 'Jardim Petrópolis x Trapiche / Farol (Integração)', 'volta'),
(391, 35084, '102', 'João Sampaio / Trapiche', 'volta'),
(392, 35085, '102', 'João Sampaio / Trapiche', 'ida'),
(393, 35093, '55', 'Chã Nova / Centro via Bebedouro - Parque', 'volta'),
(394, 35094, '55', 'Chã Nova / Centro via Bebedouro - Jaqueira', 'ida'),
(395, 35108, '55', 'Chã Nova / Centro via Bebedouro - Jaqueira', 'volta'),
(396, 35109, '55', 'Chã Nova / Centro via Bebedouro - Parque', 'ida');

-- --------------------------------------------------------

--
-- Estrutura para tabela `rota_contem_pontos`
--

CREATE TABLE IF NOT EXISTS `rota_contem_pontos` (
  `rota_id` int(11) NOT NULL,
  `ponto_id` int(11) NOT NULL COMMENT 'Uma rota contém vários pontos. Um ponto pertence a várias rotas.',
  `ordem_ponto` int(11) NOT NULL DEFAULT '1' COMMENT 'Ordenação do ponto dentro da rota.',
  PRIMARY KEY (`rota_id`,`ponto_id`,`ordem_ponto`),
  KEY `fk_ponto_idx` (`ponto_id`),
  KEY `fk_rota_idx` (`rota_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `traducoes`
--

CREATE TABLE IF NOT EXISTS `traducoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Traduções da API original para o projeto.',
  `termo_original` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `termo_traduzido` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `termo_original_UNIQUE` (`termo_original`),
  UNIQUE KEY `termo_traduzido_UNIQUE` (`termo_traduzido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `linhas`
--
ALTER TABLE `linhas`
  ADD CONSTRAINT `fk_linhas_empresas` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_linhas_rota_ida` FOREIGN KEY (`rota_ida_id`) REFERENCES `rotas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_linhas_rota_volta` FOREIGN KEY (`rota_volta_id`) REFERENCES `rotas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `pontos`
--
ALTER TABLE `pontos`
  ADD CONSTRAINT `fk_tipo` FOREIGN KEY (`tipo`) REFERENCES `ponto_tipos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `rota_contem_pontos`
--
ALTER TABLE `rota_contem_pontos`
  ADD CONSTRAINT `fk_rota` FOREIGN KEY (`rota_id`) REFERENCES `rotas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ponto` FOREIGN KEY (`ponto_id`) REFERENCES `pontos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
